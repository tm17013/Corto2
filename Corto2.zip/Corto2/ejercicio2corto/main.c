#include <stdio.h>
#include <stdlib.h>

void intercambiar(int *a, int *b){
    *a=*a+*b;
    *b=*a-*b;
    *a=*a-*b;
}

int main(){
    int a=5;
    int b=10;

    intercambiar(&a,&b);

    printf("El número de a es %d\n", a);
    printf("El número de b es %d\n", b);


    return 0;
}
