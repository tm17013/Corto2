#include <stdio.h>
//datos a utilizar
//max de 100
int size;
char toInverse[100];
char binario[100];

int decimal(int i){
    if(i==size)
        return 0;

    int x=0;
    if(binario[i]=='1')
        x=1; //si es igual a 1 sino es 0
    else
        x=0;
        return (x << i) + decimal(i+1); //recursividad



}
int main(void) {
    printf("Ingrese tamaño:\n");
    scanf("%d", &size);
    printf("Introduce el binario");
    scanf("%s", &toInverse);

    //para operar el binario.
    //invertir
    for (int s = 0; s < size; s++) {
        binario[s] = toInverse[size - 1 - s];
    }
    int resultado = decimal(0);

    printf("El binario a Decimal es : %d\n", resultado);//resultado en decimal
}